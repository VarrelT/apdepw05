﻿namespace TH_ApDev_Week_5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_product = new System.Windows.Forms.Label();
            this.lbl_category = new System.Windows.Forms.Label();
            this.lbl_details = new System.Windows.Forms.Label();
            this.lbl_namaCategory = new System.Windows.Forms.Label();
            this.lbl_namaDetails = new System.Windows.Forms.Label();
            this.lbl_categoryDetails = new System.Windows.Forms.Label();
            this.lbl_harga = new System.Windows.Forms.Label();
            this.lbl_stock = new System.Windows.Forms.Label();
            this.dtproduct = new System.Windows.Forms.DataGridView();
            this.dtcategory = new System.Windows.Forms.DataGridView();
            this.btn_all = new System.Windows.Forms.Button();
            this.btn_filter = new System.Windows.Forms.Button();
            this.cb_filter = new System.Windows.Forms.ComboBox();
            this.cb_category = new System.Windows.Forms.ComboBox();
            this.btn_addCategory = new System.Windows.Forms.Button();
            this.btn_removeCategory = new System.Windows.Forms.Button();
            this.btn_addProduct = new System.Windows.Forms.Button();
            this.btn_editProduct = new System.Windows.Forms.Button();
            this.btn_removeProduct = new System.Windows.Forms.Button();
            this.tb_namaCategory = new System.Windows.Forms.TextBox();
            this.tb_namaDetails = new System.Windows.Forms.TextBox();
            this.tb_hargaDetails = new System.Windows.Forms.TextBox();
            this.tb_stockDetails = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dtproduct)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtcategory)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_product
            // 
            this.lbl_product.AutoSize = true;
            this.lbl_product.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_product.Location = new System.Drawing.Point(40, 18);
            this.lbl_product.Name = "lbl_product";
            this.lbl_product.Size = new System.Drawing.Size(106, 29);
            this.lbl_product.TabIndex = 0;
            this.lbl_product.Text = "Product";
            // 
            // lbl_category
            // 
            this.lbl_category.AutoSize = true;
            this.lbl_category.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_category.Location = new System.Drawing.Point(579, 18);
            this.lbl_category.Name = "lbl_category";
            this.lbl_category.Size = new System.Drawing.Size(122, 29);
            this.lbl_category.TabIndex = 1;
            this.lbl_category.Text = "Category";
            // 
            // lbl_details
            // 
            this.lbl_details.AutoSize = true;
            this.lbl_details.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_details.Location = new System.Drawing.Point(40, 468);
            this.lbl_details.Name = "lbl_details";
            this.lbl_details.Size = new System.Drawing.Size(96, 29);
            this.lbl_details.TabIndex = 2;
            this.lbl_details.Text = "Details";
            // 
            // lbl_namaCategory
            // 
            this.lbl_namaCategory.AutoSize = true;
            this.lbl_namaCategory.Location = new System.Drawing.Point(580, 313);
            this.lbl_namaCategory.Name = "lbl_namaCategory";
            this.lbl_namaCategory.Size = new System.Drawing.Size(59, 20);
            this.lbl_namaCategory.TabIndex = 3;
            this.lbl_namaCategory.Text = "Nama :";
            // 
            // lbl_namaDetails
            // 
            this.lbl_namaDetails.AutoSize = true;
            this.lbl_namaDetails.Location = new System.Drawing.Point(41, 512);
            this.lbl_namaDetails.Name = "lbl_namaDetails";
            this.lbl_namaDetails.Size = new System.Drawing.Size(59, 20);
            this.lbl_namaDetails.TabIndex = 4;
            this.lbl_namaDetails.Text = "Nama :";
            // 
            // lbl_categoryDetails
            // 
            this.lbl_categoryDetails.AutoSize = true;
            this.lbl_categoryDetails.Location = new System.Drawing.Point(19, 543);
            this.lbl_categoryDetails.Name = "lbl_categoryDetails";
            this.lbl_categoryDetails.Size = new System.Drawing.Size(81, 20);
            this.lbl_categoryDetails.TabIndex = 5;
            this.lbl_categoryDetails.Text = "Category :";
            // 
            // lbl_harga
            // 
            this.lbl_harga.AutoSize = true;
            this.lbl_harga.Location = new System.Drawing.Point(39, 574);
            this.lbl_harga.Name = "lbl_harga";
            this.lbl_harga.Size = new System.Drawing.Size(61, 20);
            this.lbl_harga.TabIndex = 6;
            this.lbl_harga.Text = "Harga :";
            // 
            // lbl_stock
            // 
            this.lbl_stock.AutoSize = true;
            this.lbl_stock.Location = new System.Drawing.Point(42, 604);
            this.lbl_stock.Name = "lbl_stock";
            this.lbl_stock.Size = new System.Drawing.Size(58, 20);
            this.lbl_stock.TabIndex = 7;
            this.lbl_stock.Text = "Stock :";
            // 
            // dtproduct
            // 
            this.dtproduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtproduct.Location = new System.Drawing.Point(43, 78);
            this.dtproduct.Name = "dtproduct";
            this.dtproduct.RowHeadersVisible = false;
            this.dtproduct.RowHeadersWidth = 62;
            this.dtproduct.RowTemplate.Height = 28;
            this.dtproduct.Size = new System.Drawing.Size(503, 366);
            this.dtproduct.TabIndex = 8;
            this.dtproduct.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtproduct_CellContentClick);
            // 
            // dtcategory
            // 
            this.dtcategory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtcategory.Location = new System.Drawing.Point(584, 68);
            this.dtcategory.Name = "dtcategory";
            this.dtcategory.RowHeadersVisible = false;
            this.dtcategory.RowHeadersWidth = 62;
            this.dtcategory.RowTemplate.Height = 28;
            this.dtcategory.Size = new System.Drawing.Size(285, 208);
            this.dtcategory.TabIndex = 9;
            // 
            // btn_all
            // 
            this.btn_all.Location = new System.Drawing.Point(242, 35);
            this.btn_all.Name = "btn_all";
            this.btn_all.Size = new System.Drawing.Size(71, 37);
            this.btn_all.TabIndex = 10;
            this.btn_all.Text = "All";
            this.btn_all.UseVisualStyleBackColor = true;
            this.btn_all.Click += new System.EventHandler(this.btn_all_Click);
            // 
            // btn_filter
            // 
            this.btn_filter.Location = new System.Drawing.Point(319, 35);
            this.btn_filter.Name = "btn_filter";
            this.btn_filter.Size = new System.Drawing.Size(71, 37);
            this.btn_filter.TabIndex = 11;
            this.btn_filter.Text = "Filter :";
            this.btn_filter.UseVisualStyleBackColor = true;
            this.btn_filter.Click += new System.EventHandler(this.btn_filter_Click);
            // 
            // cb_filter
            // 
            this.cb_filter.FormattingEnabled = true;
            this.cb_filter.Location = new System.Drawing.Point(412, 35);
            this.cb_filter.Name = "cb_filter";
            this.cb_filter.Size = new System.Drawing.Size(134, 28);
            this.cb_filter.TabIndex = 12;
            this.cb_filter.SelectedIndexChanged += new System.EventHandler(this.cb_filter_SelectedIndexChanged);
            // 
            // cb_category
            // 
            this.cb_category.FormattingEnabled = true;
            this.cb_category.Location = new System.Drawing.Point(105, 540);
            this.cb_category.Name = "cb_category";
            this.cb_category.Size = new System.Drawing.Size(126, 28);
            this.cb_category.TabIndex = 13;
            // 
            // btn_addCategory
            // 
            this.btn_addCategory.Location = new System.Drawing.Point(642, 353);
            this.btn_addCategory.Name = "btn_addCategory";
            this.btn_addCategory.Size = new System.Drawing.Size(93, 63);
            this.btn_addCategory.TabIndex = 14;
            this.btn_addCategory.Text = "Add Category";
            this.btn_addCategory.UseVisualStyleBackColor = true;
            this.btn_addCategory.Click += new System.EventHandler(this.btn_addCategory_Click);
            // 
            // btn_removeCategory
            // 
            this.btn_removeCategory.Location = new System.Drawing.Point(741, 353);
            this.btn_removeCategory.Name = "btn_removeCategory";
            this.btn_removeCategory.Size = new System.Drawing.Size(93, 63);
            this.btn_removeCategory.TabIndex = 15;
            this.btn_removeCategory.Text = "Remove Category";
            this.btn_removeCategory.UseVisualStyleBackColor = true;
            this.btn_removeCategory.Click += new System.EventHandler(this.btn_removeCategory_Click);
            // 
            // btn_addProduct
            // 
            this.btn_addProduct.Location = new System.Drawing.Point(254, 574);
            this.btn_addProduct.Name = "btn_addProduct";
            this.btn_addProduct.Size = new System.Drawing.Size(93, 58);
            this.btn_addProduct.TabIndex = 16;
            this.btn_addProduct.Text = "Add Product";
            this.btn_addProduct.UseVisualStyleBackColor = true;
            this.btn_addProduct.Click += new System.EventHandler(this.btn_addProduct_Click);
            // 
            // btn_editProduct
            // 
            this.btn_editProduct.Location = new System.Drawing.Point(353, 574);
            this.btn_editProduct.Name = "btn_editProduct";
            this.btn_editProduct.Size = new System.Drawing.Size(93, 58);
            this.btn_editProduct.TabIndex = 17;
            this.btn_editProduct.Text = "Edit Product";
            this.btn_editProduct.UseVisualStyleBackColor = true;
            this.btn_editProduct.Click += new System.EventHandler(this.btn_editProduct_Click);
            // 
            // btn_removeProduct
            // 
            this.btn_removeProduct.Location = new System.Drawing.Point(452, 574);
            this.btn_removeProduct.Name = "btn_removeProduct";
            this.btn_removeProduct.Size = new System.Drawing.Size(93, 58);
            this.btn_removeProduct.TabIndex = 18;
            this.btn_removeProduct.Text = "Remove Product";
            this.btn_removeProduct.UseVisualStyleBackColor = true;
            this.btn_removeProduct.Click += new System.EventHandler(this.btn_removeProduct_Click);
            // 
            // tb_namaCategory
            // 
            this.tb_namaCategory.Location = new System.Drawing.Point(645, 310);
            this.tb_namaCategory.Name = "tb_namaCategory";
            this.tb_namaCategory.Size = new System.Drawing.Size(189, 26);
            this.tb_namaCategory.TabIndex = 19;
            // 
            // tb_namaDetails
            // 
            this.tb_namaDetails.Location = new System.Drawing.Point(106, 509);
            this.tb_namaDetails.Name = "tb_namaDetails";
            this.tb_namaDetails.Size = new System.Drawing.Size(440, 26);
            this.tb_namaDetails.TabIndex = 20;
            // 
            // tb_hargaDetails
            // 
            this.tb_hargaDetails.Location = new System.Drawing.Point(106, 574);
            this.tb_hargaDetails.Name = "tb_hargaDetails";
            this.tb_hargaDetails.Size = new System.Drawing.Size(125, 26);
            this.tb_hargaDetails.TabIndex = 21;
            // 
            // tb_stockDetails
            // 
            this.tb_stockDetails.Location = new System.Drawing.Point(106, 606);
            this.tb_stockDetails.Name = "tb_stockDetails";
            this.tb_stockDetails.Size = new System.Drawing.Size(125, 26);
            this.tb_stockDetails.TabIndex = 22;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSeaGreen;
            this.ClientSize = new System.Drawing.Size(890, 673);
            this.Controls.Add(this.tb_stockDetails);
            this.Controls.Add(this.tb_hargaDetails);
            this.Controls.Add(this.tb_namaDetails);
            this.Controls.Add(this.tb_namaCategory);
            this.Controls.Add(this.btn_removeProduct);
            this.Controls.Add(this.btn_editProduct);
            this.Controls.Add(this.btn_addProduct);
            this.Controls.Add(this.btn_removeCategory);
            this.Controls.Add(this.btn_addCategory);
            this.Controls.Add(this.cb_category);
            this.Controls.Add(this.cb_filter);
            this.Controls.Add(this.btn_filter);
            this.Controls.Add(this.btn_all);
            this.Controls.Add(this.dtcategory);
            this.Controls.Add(this.dtproduct);
            this.Controls.Add(this.lbl_stock);
            this.Controls.Add(this.lbl_harga);
            this.Controls.Add(this.lbl_categoryDetails);
            this.Controls.Add(this.lbl_namaDetails);
            this.Controls.Add(this.lbl_namaCategory);
            this.Controls.Add(this.lbl_details);
            this.Controls.Add(this.lbl_category);
            this.Controls.Add(this.lbl_product);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtproduct)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtcategory)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_product;
        private System.Windows.Forms.Label lbl_category;
        private System.Windows.Forms.Label lbl_details;
        private System.Windows.Forms.Label lbl_namaCategory;
        private System.Windows.Forms.Label lbl_namaDetails;
        private System.Windows.Forms.Label lbl_categoryDetails;
        private System.Windows.Forms.Label lbl_harga;
        private System.Windows.Forms.Label lbl_stock;
        private System.Windows.Forms.DataGridView dtproduct;
        private System.Windows.Forms.DataGridView dtcategory;
        private System.Windows.Forms.Button btn_all;
        private System.Windows.Forms.Button btn_filter;
        private System.Windows.Forms.ComboBox cb_filter;
        private System.Windows.Forms.ComboBox cb_category;
        private System.Windows.Forms.Button btn_addCategory;
        private System.Windows.Forms.Button btn_removeCategory;
        private System.Windows.Forms.Button btn_addProduct;
        private System.Windows.Forms.Button btn_editProduct;
        private System.Windows.Forms.Button btn_removeProduct;
        private System.Windows.Forms.TextBox tb_namaCategory;
        private System.Windows.Forms.TextBox tb_namaDetails;
        private System.Windows.Forms.TextBox tb_hargaDetails;
        private System.Windows.Forms.TextBox tb_stockDetails;
    }
}

