﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TH_ApDev_Week_5
{
    public partial class Form1 : Form
    {
        DataTable dt = new DataTable();
        DataTable dt2 = new DataTable();
        DataTable dtproduktampil = new DataTable();

        public Form1()
        {
            InitializeComponent();

            dt.Columns.Add("ID Product");
            dt.Columns.Add("Nama Product");
            dt.Columns.Add("Harga");
            dt.Columns.Add("Stock");
            dt.Columns.Add("ID Category");
            dt.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dt.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dt.Rows.Add("T002", "T-Shirt Obsessive", "75000", "16", "C2");
            dt.Rows.Add("R001", "Rok Mini ", "82000", "26", "C3");
            dt.Rows.Add("J002", "Jeans Biru ", "90000", "5", "C4");
            dt.Rows.Add("C001", "Celana Pendek Coklat ", "60000", "11", "C4");
            dt.Rows.Add("C002", "Cawat Blink-Blink ", "1000000", "1", "C5");
            dt.Rows.Add("R001", "Rocca Shirt ", "50000", "8", "C2");

            dt2.Columns.Add("ID Category");
            dt2.Columns.Add("Nama Category");
            dt2.Rows.Add("C1", "Jas");
            dt2.Rows.Add("C2", "T-Shirt");
            dt2.Rows.Add("C3", "Rok");
            dt2.Rows.Add("C4", "Celana");
            dt2.Rows.Add("C5", "Cawat");

            dtproduct.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dtcategory.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            cb_filter.Enabled = false;
            display_Product();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void display_Product()
        {
            dtproduktampil = dt.Copy();
            dtproduct.DataSource = dt;
            dtproduct.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dtcategory.DataSource = dt2;
            dtcategory.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;


            cb_filter.Items.Clear();
            cb_category.Items.Clear();
            foreach (DataRow row in dt2.Rows)
            {
                cb_filter.Items.Add(row["Nama Category"].ToString());
                cb_category.Items.Add(row["Nama Category"].ToString());
            }
        }

        private void btn_addCategory_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tb_namaCategory.Text))
            {
                MessageBox.Show("Error");
                return;
            }

            string categoryName = tb_namaCategory.Text.Trim();

            foreach (DataRow row in dt2.Rows)
            {
                if (row["Nama Category"].ToString().Equals(categoryName, StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show("Error");
                    return;
                }
            }

            string lastCategoryId = "";
            if (dt2.Rows.Count > 0)
            {
                lastCategoryId = dt2.Rows[dt2.Rows.Count - 1]["ID Category"].ToString();
            }
            string newCategoryId = GenerateNextCategoryId(lastCategoryId);

            dt2.Rows.Add(newCategoryId, categoryName);
            dtcategory.DataSource = dt2;

            cb_filter.Items.Clear();
            cb_category.Items.Clear();
            foreach (DataRow row in dt2.Rows)
            {
                cb_filter.Items.Add(row["Nama Category"].ToString());
                cb_category.Items.Add(row["Nama Category"].ToString());
            }
            tb_namaCategory.Clear();
        }

        private string GenerateNextCategoryId(string categoryid)
        {
            string newCategoryId = "C1";

            if (!string.IsNullOrEmpty(categoryid))
            {
                int lastId = int.Parse(categoryid.Substring(1));
                int nextId = lastId + 1;

                newCategoryId = "C" + nextId.ToString();
            }
            return newCategoryId;
        }

        private void btn_removeCategory_Click(object sender, EventArgs e)
        {
            if (dtcategory.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dtcategory.SelectedRows[0];
                string selectedCategoryId = selectedRow.Cells["ID Category"].Value.ToString();

                DataRow[] matchingCategoryRows = dt2.Select($"[ID Category] = '{selectedCategoryId}'");
                foreach (DataRow categoryRow in matchingCategoryRows)
                {
                    dt2.Rows.Remove(categoryRow);
                }

                DataRow[] matchingProductRows = dt.Select($"[ID Category] = '{selectedCategoryId}'");
                foreach (DataRow productRow in matchingProductRows)
                {
                    dt.Rows.Remove(productRow);
                }

                display_Product();
            }
            else
            {
                MessageBox.Show("Error");
            }
        }



        private void btn_addProduct_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tb_namaDetails.Text) ||
                string.IsNullOrWhiteSpace(tb_hargaDetails.Text) ||
                string.IsNullOrWhiteSpace(tb_stockDetails.Text) ||
                cb_category.SelectedItem == null)
            {
                MessageBox.Show("Mohon isi semua data produk.", "Error");
                return;
            }

            if (!int.TryParse(tb_hargaDetails.Text, out _) || !int.TryParse(tb_stockDetails.Text, out _))
            {
                MessageBox.Show("Harga dan stock harus berupa angka.", "Error");
                return;
            }

            string firstChar = tb_namaDetails.Text[0].ToString();
            string categoryId = dt2.AsEnumerable().Where(row => row.Field<string>("Nama Category").StartsWith(firstChar)).Select(row => row.Field<string>("ID Category")).FirstOrDefault();

            if (categoryId == null)
            {
                categoryId = "C1";
            }

            if (cb_category.SelectedItem != null)
            {
                categoryId = dt2.AsEnumerable().Where(row => row.Field<string>("Nama Category") == cb_category.SelectedItem.ToString()).Select(row => row.Field<string>("ID Category")).FirstOrDefault();
            }

            int count = dt.AsEnumerable().Count(row => row.Field<string>("Nama Product").StartsWith(tb_namaDetails.Text));

            string id = firstChar + (count + 1).ToString("D3");

            dt.Rows.Add(id, tb_namaDetails.Text, tb_hargaDetails.Text, tb_stockDetails.Text, categoryId);
            display_Product();
        }

        private void btn_editProduct_Click(object sender, EventArgs e)
        {
            if (dtproduct.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dtproduct.SelectedRows[0];

                if (string.IsNullOrWhiteSpace(tb_namaDetails.Text) || string.IsNullOrWhiteSpace(tb_hargaDetails.Text) ||  string.IsNullOrWhiteSpace(tb_stockDetails.Text) || cb_category.SelectedItem == null)
                {
                    MessageBox.Show("Mohon isi semua data produk.", "Error");
                    return;
                }

                if (!int.TryParse(tb_hargaDetails.Text, out int harga) || !int.TryParse(tb_stockDetails.Text, out int stock))
                {
                    MessageBox.Show("Harga dan stock harus berupa angka.", "Error");
                    return;
                }

                string selectedProductId = selectedRow.Cells["ID Product"].Value.ToString();

                DataRow[] matchingRows = dt.Select($"[ID Product] = '{selectedProductId}'");
                if (matchingRows.Length > 0)
                {
                    DataRow row = matchingRows[0];
                    row["Nama Product"] = tb_namaDetails.Text;
                    row["Harga"] = harga;
                    row["Stock"] = stock;

                    string categoryId = "";
                    if (cb_category.SelectedItem != null)
                    {
                        string selectedCategoryName = cb_category.SelectedItem.ToString();
                        DataRow[] categoryRows = dt2.Select($"[Nama Category] = '{selectedCategoryName}'");
                        if (categoryRows.Length > 0)
                        {
                            categoryId = categoryRows[0]["ID Category"].ToString();
                        }
                    }
                    row["ID Category"] = categoryId;

                    dtproduct.DataSource = dt;

                    if (stock == 0)
                    {
                        dt.Rows.Remove(row);
                        dtproduct.DataSource = dt;
                    }
                }
            }
            else
            {
                MessageBox.Show("Error");
            }
        }

        private void btn_removeProduct_Click(object sender, EventArgs e)
        {
            if (dtproduct.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dtproduct.SelectedRows)
                {
                    dt.Rows.RemoveAt(row.Index);
                }
            }
            else
            {
                MessageBox.Show("Pilih baris yang ingin dihapus.");
            }
            dtproduct.ClearSelection();
        }

        private void btn_all_Click(object sender, EventArgs e)
        {
            display_Product();
            cb_filter.Enabled = false;
        }

        private void btn_filter_Click(object sender, EventArgs e)
        {
            cb_filter.Enabled = true;
        }

        private void cb_filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_filter.SelectedItem != null)
            {
                string selectedCategory = cb_filter.SelectedItem.ToString();
                string categoryId = dt2.AsEnumerable().Where(row => row.Field<string>("Nama Category") == selectedCategory).Select(row => row.Field<string>("ID Category")).FirstOrDefault();

                if (categoryId != null)
                {
                    DataView dv = new DataView(dt);
                    dv.RowFilter = $"[ID Category] = '{categoryId}'";
                    dtproduktampil = dv.ToTable();
                    dtproduct.DataSource = dtproduktampil;
                }
                else
                {
                    MessageBox.Show("Error");
                }
            }
        }

        private void dtproduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dtproduct.Rows[e.RowIndex];
                tb_namaDetails.Text = selectedRow.Cells["Nama Product"].Value.ToString();
                string selectedCategoryId = selectedRow.Cells["ID Category"].Value.ToString();
                string categoryName = dt2.AsEnumerable().Where(row => row.Field<string>("ID Category") == selectedCategoryId).Select(row => row.Field<string>("Nama Category")).FirstOrDefault();
                cb_category.SelectedItem = categoryName;
                tb_hargaDetails.Text = selectedRow.Cells["Harga"].Value.ToString();
                tb_stockDetails.Text = selectedRow.Cells["Stock"].Value.ToString();
            }
        }
    }
}

